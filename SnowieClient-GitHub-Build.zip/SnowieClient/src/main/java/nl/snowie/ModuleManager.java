package nl.snowie;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import nl.snowie.modules.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class ModuleManager {
    public final List<SnowModule> modules = new ArrayList<>();

    public ModuleManager() {
        // Combat
        modules.add(new AutoTotem());
        modules.add(new AimAssist());
        modules.add(new AutoCrystal());
        modules.add(new AutoAnchor());
        modules.add(new AntiKnockback());
        // Movement
        modules.add(new Fly());
        modules.add(new Jesus());
        modules.add(new NoDamage());
        modules.add(new Freecam());
        // Render
        modules.add(new PlayerEsp());
        modules.add(new BlockEsp());
        modules.add(new XRay());
        modules.add(new CustomSky());
        // World
        modules.add(new SusChunkFinder());
        modules.add(new PlayerFinder());
        // Player
        modules.add(new AutoEat());
        // HUD
        modules.add(new StaffGui());
        modules.add(new TimeDateGui());
    }

    public <T extends SnowModule> T get(Class<T> type) {
        for (SnowModule m : modules) if (type.isInstance(m)) return type.cast(m);
        return null;
    }

    public boolean on(Class<? extends SnowModule> type) {
        SnowModule m = get(type);
        return m != null && m.isEnabled();
    }

    public void tick() {
        for (SnowModule m : modules) {
            if (!m.isEnabled()) continue;
            try { m.onTick(); } catch (Throwable t) { t.printStackTrace(); }
        }
    }

    public void hud(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden || mc.player == null) return;

        Hud.leftY = 6;
        Hud.panel(ctx, "Snowie Client", List.of(mc.getCurrentFps() + " fps"));

        for (SnowModule m : modules) {
            if (!m.isEnabled()) continue;
            try { m.onHud(ctx); } catch (Throwable t) { t.printStackTrace(); }
        }

        // Active module list (right side)
        List<SnowModule> active = new ArrayList<>();
        for (SnowModule m : modules) if (m.isEnabled()) active.add(m);
        active.sort(Comparator.comparingInt((SnowModule m) -> -mc.textRenderer.getWidth(m.name)));
        int y = 6;
        int sw = ctx.getScaledWindowWidth();
        for (SnowModule m : active) {
            int w = mc.textRenderer.getWidth(m.name);
            ctx.fill(sw - w - 10, y, sw - 4, y + 11, Theme.HUD_BG);
            ctx.fill(sw - 4, y, sw - 2, y + 11, Theme.ICE);
            ctx.drawText(mc.textRenderer, m.name, sw - w - 7, y + 2, Theme.SNOW, false);
            y += 11;
        }
    }
}
