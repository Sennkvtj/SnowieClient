package nl.snowie.modules;

import net.minecraft.block.Block;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.registry.Registries;
import nl.snowie.Category;
import nl.snowie.SnowModule;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Only ore-like blocks are drawn (see BlockMixin). Works with vanilla rendering; Sodium bypasses it. */
public class XRay extends SnowModule {
    public static boolean active;
    private static final Map<Block, Boolean> CACHE = new ConcurrentHashMap<>();

    public XRay() { super("X-Ray", "See ores through the terrain", Category.RENDER); }

    public static boolean visible(Block block) {
        return CACHE.computeIfAbsent(block, b -> {
            String path = Registries.BLOCK.getId(b).getPath();
            return path.endsWith("_ore") || path.equals("ancient_debris") || path.equals("spawner")
                    || path.endsWith("chest") || path.equals("lava") || path.equals("water") || path.equals("beacon");
        });
    }

    @Override
    public void onEnable() {
        active = true;
        if (mc.worldRenderer != null) mc.worldRenderer.reload();
    }

    @Override
    public void onTick() {
        if (!ready()) return;
        if (!mc.player.hasStatusEffect(StatusEffects.NIGHT_VISION)) {
            mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 100000, 0, false, false));
        }
    }

    @Override
    public void onDisable() {
        active = false;
        if (mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        if (mc.worldRenderer != null) mc.worldRenderer.reload();
    }
}
