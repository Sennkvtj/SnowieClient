package nl.snowie.modules;

import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import nl.snowie.Category;
import nl.snowie.SnowModule;

/**
 * A client can never fully block damage (the server decides). This module removes fall damage
 * by telling the server you are on the ground (NoFall).
 */
public class NoDamage extends SnowModule {
    public NoDamage() { super("NoDamage", "No fall damage (NoFall)", Category.MOVEMENT); }

    @Override
    public void onTick() {
        if (!ready() || mc.getNetworkHandler() == null) return;
        var p = mc.player;
        if (p.fallDistance > 2.5 && !p.isOnGround() && !p.isGliding()) {
            mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(true, false));
        }
    }
}
