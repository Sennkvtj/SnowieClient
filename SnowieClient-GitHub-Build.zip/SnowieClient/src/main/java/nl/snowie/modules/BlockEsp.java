package nl.snowie.modules;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.BlockPos;
import nl.snowie.Category;
import nl.snowie.SnowModule;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class BlockEsp extends SnowModule {
    private static final Set<Block> TARGETS = Set.of(
            Blocks.DIAMOND_ORE, Blocks.DEEPSLATE_DIAMOND_ORE, Blocks.EMERALD_ORE, Blocks.DEEPSLATE_EMERALD_ORE,
            Blocks.ANCIENT_DEBRIS, Blocks.SPAWNER, Blocks.CHEST, Blocks.TRAPPED_CHEST,
            Blocks.ENDER_CHEST, Blocks.BEACON);
    private final List<BlockPos> found = new ArrayList<>();
    private int tick;

    public BlockEsp() { super("BlockESP", "Marks valuable blocks with snow sparkles", Category.RENDER); }

    @Override
    public void onTick() {
        if (!ready()) return;
        tick++;
        if (tick % 20 == 0) {
            found.clear();
            BlockPos c = mc.player.getBlockPos();
            for (BlockPos pos : BlockPos.iterate(c.add(-16, -16, -16), c.add(16, 16, 16))) {
                if (found.size() >= 64) break;
                if (TARGETS.contains(mc.world.getBlockState(pos).getBlock())) found.add(pos.toImmutable());
            }
        }
        if (tick % 4 == 0) {
            for (BlockPos pos : found) {
                mc.world.addParticleClient(ParticleTypes.END_ROD,
                        pos.getX() + mc.world.random.nextDouble(), pos.getY() + 1.05, pos.getZ() + mc.world.random.nextDouble(),
                        0, 0.02, 0);
            }
        }
    }
}
