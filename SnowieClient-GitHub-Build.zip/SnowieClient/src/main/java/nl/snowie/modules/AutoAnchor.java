package nl.snowie.modules;

import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import nl.snowie.Category;
import nl.snowie.SnowModule;

public class AutoAnchor extends SnowModule {
    private int cooldown;

    public AutoAnchor() { super("AutoAnchor", "Places, charges and detonates respawn anchors", Category.COMBAT); }

    @Override
    public void onTick() {
        if (!ready() || mc.currentScreen != null) return;
        if (cooldown-- > 0) return;
        var p = mc.player;
        PlayerEntity target = nearestPlayer(7);
        if (target == null) return;

        BlockPos anchor = null;
        BlockPos c = p.getBlockPos();
        for (BlockPos pos : BlockPos.iterate(c.add(-4, -4, -4), c.add(4, 4, 4))) {
            if (!mc.world.getBlockState(pos).isOf(Blocks.RESPAWN_ANCHOR)) continue;
            if (p.getEyePos().distanceTo(Vec3d.ofCenter(pos)) > 4.5) continue;
            if (pos.getSquaredDistance(target.getPos()) > 25) continue;
            anchor = pos.toImmutable();
            break;
        }

        if (anchor != null) {
            int charges = mc.world.getBlockState(anchor).get(RespawnAnchorBlock.CHARGES);
            if (charges == 0) {
                int glow = findHotbar(s -> s.isOf(Items.GLOWSTONE));
                if (glow == -1) return;
                p.getInventory().setSelectedSlot(glow);
            } else {
                int other = findHotbar(s -> !s.isOf(Items.GLOWSTONE));
                if (other == -1) return;
                p.getInventory().setSelectedSlot(other);
            }
            mc.interactionManager.interactBlock(p, Hand.MAIN_HAND,
                    new BlockHitResult(Vec3d.ofCenter(anchor), Direction.UP, anchor, false));
            p.swingHand(Hand.MAIN_HAND);
            cooldown = 3;
            return;
        }

        int slot = findHotbar(s -> s.isOf(Items.RESPAWN_ANCHOR));
        if (slot == -1) return;
        for (Direction d : Direction.Type.HORIZONTAL) {
            BlockPos place = target.getBlockPos().offset(d);
            BlockPos support = place.down();
            if (!mc.world.getBlockState(place).isAir() || mc.world.getBlockState(support).isAir()) continue;
            if (p.getEyePos().distanceTo(Vec3d.ofCenter(support)) > 4.5) continue;
            p.getInventory().setSelectedSlot(slot);
            mc.interactionManager.interactBlock(p, Hand.MAIN_HAND,
                    new BlockHitResult(Vec3d.ofCenter(support).add(0, 0.5, 0), Direction.UP, support, false));
            p.swingHand(Hand.MAIN_HAND);
            cooldown = 3;
            return;
        }
    }
}
