package nl.snowie.modules;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import nl.snowie.Category;
import nl.snowie.SnowModule;

public class AimAssist extends SnowModule {
    public AimAssist() { super("AimAssist", "Smoothly aims at nearby players while attacking", Category.COMBAT); }

    @Override
    public void onTick() {
        if (!ready() || mc.currentScreen != null || !mc.options.attackKey.isPressed()) return;
        var p = mc.player;
        PlayerEntity best = null;
        double bestAngle = 70;
        for (PlayerEntity e : mc.world.getPlayers()) {
            if (e == p || !e.isAlive() || e.isSpectator() || p.distanceTo(e) > 5.0) continue;
            double[] a = angles(e.getBoundingBox().getCenter());
            double diff = Math.hypot(MathHelper.wrapDegrees(a[0] - p.getYaw()), a[1] - p.getPitch());
            if (diff < bestAngle) { bestAngle = diff; best = e; }
        }
        if (best == null) return;
        double[] a = angles(best.getBoundingBox().getCenter());
        float dy = (float) MathHelper.wrapDegrees(a[0] - p.getYaw());
        float dp = (float) (a[1] - p.getPitch());
        p.setYaw(p.getYaw() + MathHelper.clamp(dy * 0.2f, -5f, 5f));
        p.setPitch(MathHelper.clamp(p.getPitch() + MathHelper.clamp(dp * 0.2f, -5f, 5f), -90f, 90f));
    }

    private double[] angles(Vec3d target) {
        Vec3d eye = mc.player.getEyePos();
        double dx = target.x - eye.x, dy = target.y - eye.y, dz = target.z - eye.z;
        double yaw = Math.toDegrees(Math.atan2(dz, dx)) - 90.0;
        double pitch = -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)));
        return new double[]{yaw, pitch};
    }
}
