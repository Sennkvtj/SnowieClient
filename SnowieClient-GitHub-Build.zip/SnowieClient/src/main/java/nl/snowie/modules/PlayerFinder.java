package nl.snowie.modules;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.player.PlayerEntity;
import nl.snowie.Category;
import nl.snowie.Hud;
import nl.snowie.SnowModule;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class PlayerFinder extends SnowModule {
    public PlayerFinder() { super("PlayerFinder", "Lists players with distance and coordinates", Category.WORLD); }

    @Override
    public void onHud(DrawContext ctx) {
        if (!ready()) return;
        List<String> lines = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        List<PlayerEntity> near = new ArrayList<>(mc.world.getPlayers());
        near.removeIf(e -> e == mc.player);
        near.sort(Comparator.comparingDouble(e -> mc.player.squaredDistanceTo(e)));
        for (PlayerEntity e : near) {
            if (lines.size() >= 8) break;
            String name = e.getGameProfile().name();
            seen.add(name);
            lines.add(String.format("%s  %.0fm  [%d %d %d]", name, mc.player.distanceTo(e), (int) e.getX(), (int) e.getY(), (int) e.getZ()));
        }
        if (mc.getNetworkHandler() != null) {
            for (PlayerListEntry entry : mc.getNetworkHandler().getPlayerList()) {
                if (lines.size() >= 8) break;
                String name = entry.getProfile().name();
                if (name.equals(mc.player.getGameProfile().name()) || seen.contains(name)) continue;
                lines.add(name + "  (out of range)");
            }
        }
        if (lines.isEmpty()) lines.add("No other players");
        Hud.panel(ctx, "Players", lines);
    }
}
