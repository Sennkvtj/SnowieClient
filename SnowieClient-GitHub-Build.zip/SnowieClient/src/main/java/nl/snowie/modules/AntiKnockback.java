package nl.snowie.modules;

import nl.snowie.Category;
import nl.snowie.SnowModule;

/** Logic lives in ClientPlayNetworkHandlerMixin (cancels velocity packets for the local player). */
public class AntiKnockback extends SnowModule {
    public AntiKnockback() { super("AntiKnockback", "Ignores knockback from hits", Category.COMBAT); }
}
