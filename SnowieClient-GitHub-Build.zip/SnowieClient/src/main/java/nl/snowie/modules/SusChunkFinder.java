package nl.snowie.modules;

import net.minecraft.block.entity.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.world.chunk.WorldChunk;
import nl.snowie.Category;
import nl.snowie.Hud;
import nl.snowie.SnowModule;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Heuristic: loaded chunks with many storage/utility block entities probably contain a base. */
public class SusChunkFinder extends SnowModule {
    private record Sus(int cx, int cz, int score) {}
    private final List<Sus> results = new ArrayList<>();
    private int tick;

    public SusChunkFinder() { super("SusChunkFinder", "Finds chunks that look like bases", Category.WORLD); }

    @Override
    public void onTick() {
        if (!ready() || tick++ % 40 != 0) return;
        results.clear();
        int pcx = mc.player.getChunkPos().x, pcz = mc.player.getChunkPos().z;
        int r = Math.min(mc.options.getClampedViewDistance(), 16);
        for (int cx = pcx - r; cx <= pcx + r; cx++) {
            for (int cz = pcz - r; cz <= pcz + r; cz++) {
                WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(cx, cz);
                if (chunk == null) continue;
                int score = 0;
                for (BlockEntity be : chunk.getBlockEntities().values()) {
                    if (be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity || be instanceof HopperBlockEntity
                            || be instanceof AbstractFurnaceBlockEntity || be instanceof DispenserBlockEntity) score += 1;
                    else if (be instanceof ShulkerBoxBlockEntity || be instanceof EnderChestBlockEntity) score += 3;
                    else if (be instanceof BeaconBlockEntity) score += 8;
                }
                if (score >= 8) results.add(new Sus(cx, cz, score));
            }
        }
        results.sort(Comparator.comparingInt((Sus s) -> -s.score));
    }

    @Override
    public void onHud(DrawContext ctx) {
        List<String> lines = new ArrayList<>();
        for (int i = 0; i < Math.min(5, results.size()); i++) {
            Sus s = results.get(i);
            lines.add(String.format("%d, %d  (score %d)", s.cx * 16 + 8, s.cz * 16 + 8, s.score));
        }
        if (lines.isEmpty()) lines.add("Nothing suspicious");
        Hud.panel(ctx, "Sus Chunks", lines);
    }
}
