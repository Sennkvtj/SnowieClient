package nl.snowie.modules;

import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import nl.snowie.Category;
import nl.snowie.SnowModule;

/** Camera detaches from the player; the player body stays where it is (input is zeroed by KeyboardInputMixin). */
public class Freecam extends SnowModule {
    public static Vec3d pos = Vec3d.ZERO;

    public Freecam() { super("Freecam", "Fly the camera without moving your player", Category.RENDER); }

    @Override
    public void onEnable() {
        if (mc.gameRenderer != null) pos = mc.gameRenderer.getCamera().getCameraPos();
    }

    @Override
    public void onTick() {
        if (!ready()) return;
        float yaw = mc.player.getYaw() * MathHelper.RADIANS_PER_DEGREE;
        double speed = 0.9;
        double fx = -MathHelper.sin(yaw), fz = MathHelper.cos(yaw);
        double dx = 0, dy = 0, dz = 0;
        if (mc.options.forwardKey.isPressed()) { dx += fx; dz += fz; }
        if (mc.options.backKey.isPressed()) { dx -= fx; dz -= fz; }
        if (mc.options.leftKey.isPressed()) { dx += fz; dz -= fx; }
        if (mc.options.rightKey.isPressed()) { dx -= fz; dz += fx; }
        if (mc.options.jumpKey.isPressed()) dy += 1;
        if (mc.options.sneakKey.isPressed()) dy -= 1;
        pos = pos.add(dx * speed, dy * speed, dz * speed);
    }
}
