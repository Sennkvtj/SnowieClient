package nl.snowie.modules;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import nl.snowie.Category;
import nl.snowie.SnowModule;

import java.util.Set;

public class AutoEat extends SnowModule {
    private static final Set<Item> BAD = Set.of(Items.ROTTEN_FLESH, Items.SPIDER_EYE, Items.POISONOUS_POTATO,
            Items.PUFFERFISH, Items.CHICKEN, Items.SUSPICIOUS_STEW, Items.CHORUS_FRUIT);
    private boolean eating;
    private int previous;

    public AutoEat() { super("AutoEat", "Eats automatically when hungry", Category.PLAYER); }

    @Override
    public void onTick() {
        if (!ready()) return;
        var p = mc.player;
        int food = p.getHungerManager().getFoodLevel();
        if (food <= 14 && mc.currentScreen == null) {
            int slot = findHotbar(s -> s.contains(DataComponentTypes.FOOD) && !BAD.contains(s.getItem()));
            if (slot != -1) {
                if (!eating) previous = p.getInventory().getSelectedSlot();
                p.getInventory().setSelectedSlot(slot);
                mc.options.useKey.setPressed(true);
                eating = true;
                return;
            }
        }
        if (eating && (food >= 20 || mc.currentScreen != null)) stopEating();
    }

    @Override
    public void onDisable() { if (eating) stopEating(); }

    private void stopEating() {
        mc.options.useKey.setPressed(false);
        if (mc.player != null) mc.player.getInventory().setSelectedSlot(previous);
        eating = false;
    }
}
