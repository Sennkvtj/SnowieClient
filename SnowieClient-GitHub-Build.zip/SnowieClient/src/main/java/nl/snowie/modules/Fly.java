package nl.snowie.modules;

import nl.snowie.Category;
import nl.snowie.SnowModule;

public class Fly extends SnowModule {
    public Fly() { super("Fly", "Creative-style flight", Category.MOVEMENT); }

    @Override
    public void onEnable() {
        if (mc.player != null) {
            mc.player.getAbilities().allowFlying = true;
            mc.player.getAbilities().flying = true;
        }
    }

    @Override
    public void onTick() {
        if (!ready()) return;
        var a = mc.player.getAbilities();
        a.allowFlying = true;
        a.setFlySpeed(0.08f);
    }

    @Override
    public void onDisable() {
        if (mc.player == null) return;
        var a = mc.player.getAbilities();
        a.setFlySpeed(0.05f);
        if (!mc.player.isCreative() && !mc.player.isSpectator()) {
            a.allowFlying = false;
            a.flying = false;
        }
    }
}
