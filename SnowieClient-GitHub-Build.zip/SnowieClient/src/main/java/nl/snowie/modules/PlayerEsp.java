package nl.snowie.modules;

import nl.snowie.Category;
import nl.snowie.SnowModule;

/** Logic lives in EntityMixin (players get a glow outline that is visible through walls). */
public class PlayerEsp extends SnowModule {
    public PlayerEsp() { super("PlayerESP", "Outline players through walls", Category.RENDER); }
}
