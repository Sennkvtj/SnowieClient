package nl.snowie.modules;

import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import nl.snowie.Category;
import nl.snowie.SnowModule;

public class AutoTotem extends SnowModule {
    public AutoTotem() { super("AutoTotem", "Keeps a totem in your offhand", Category.COMBAT); }

    @Override
    public void onTick() {
        if (!ready()) return;
        var p = mc.player;
        if (p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
        // slots 9..44 = main inventory + hotbar in the player screen handler
        for (int i = 9; i < 45; i++) {
            if (p.playerScreenHandler.getSlot(i).getStack().isOf(Items.TOTEM_OF_UNDYING)) {
                mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, i, 40, SlotActionType.SWAP, p);
                return;
            }
        }
    }
}
