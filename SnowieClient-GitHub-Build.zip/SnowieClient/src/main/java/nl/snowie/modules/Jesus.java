package nl.snowie.modules;

import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import nl.snowie.Category;
import nl.snowie.SnowModule;

public class Jesus extends SnowModule {
    public Jesus() { super("Jesus", "Walk on water and lava", Category.MOVEMENT); }

    @Override
    public void onTick() {
        if (!ready()) return;
        var p = mc.player;
        if (p.isSneaking()) return;
        Vec3d v = p.getVelocity();
        if (p.isTouchingWater() || p.isInLava()) {
            p.setVelocity(v.x, 0.13, v.z);
            return;
        }
        BlockPos below = BlockPos.ofFloored(p.getX(), p.getY() - 0.05, p.getZ());
        if (!mc.world.getFluidState(below).isEmpty() && v.y <= 0) {
            p.setVelocity(v.x, 0, v.z);
            p.setOnGround(true);
        }
    }
}
