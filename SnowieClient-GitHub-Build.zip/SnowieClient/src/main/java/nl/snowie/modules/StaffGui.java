package nl.snowie.modules;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.scoreboard.Team;
import net.minecraft.world.GameMode;
import nl.snowie.Category;
import nl.snowie.Hud;
import nl.snowie.SnowModule;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class StaffGui extends SnowModule {
    /** Add exact names of your own staff here. */
    private static final Set<String> STAFF_NAMES = Set.of();
    private static final String[] KEYWORDS = {"owner", "admin", "mod", "helper", "staff", "dev", "manager", "support"};

    public StaffGui() { super("StaffGUI", "Shows staff members that are online", Category.HUD); }

    @Override
    public void onHud(DrawContext ctx) {
        if (!ready() || mc.getNetworkHandler() == null) return;
        List<String> lines = new ArrayList<>();
        for (PlayerListEntry e : mc.getNetworkHandler().getPlayerList()) {
            String name = e.getProfile().name();
            String decor = e.getDisplayName() != null ? e.getDisplayName().getString() : "";
            Team team = mc.world.getScoreboard().getScoreHolderTeam(name);
            if (team != null) decor += " " + team.getPrefix().getString();
            String lower = decor.toLowerCase(Locale.ROOT);
            boolean staff = STAFF_NAMES.contains(name);
            for (String k : KEYWORDS) if (lower.contains(k)) staff = true;
            String tag = "";
            if (e.getGameMode() == GameMode.SPECTATOR) { staff = true; tag = " (spectator)"; }
            if (staff && lines.size() < 10) lines.add(name + tag);
        }
        if (lines.isEmpty()) lines.add("No staff online");
        Hud.panel(ctx, "Staff Online", lines);
    }
}
