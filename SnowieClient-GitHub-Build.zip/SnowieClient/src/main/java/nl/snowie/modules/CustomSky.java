package nl.snowie.modules;

import nl.snowie.Category;
import nl.snowie.SnowModule;

/** Icy-blue sky; see ClientWorldMixin. */
public class CustomSky extends SnowModule {
    public static boolean active;
    public static final int COLOR = 0xFFA8D8FF;

    public CustomSky() { super("CustomSky", "Icy blue snow sky", Category.RENDER); }

    @Override
    public void onEnable() { active = true; }

    @Override
    public void onDisable() { active = false; }
}
