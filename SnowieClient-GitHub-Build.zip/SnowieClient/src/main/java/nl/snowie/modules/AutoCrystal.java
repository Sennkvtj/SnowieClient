package nl.snowie.modules;

import net.minecraft.block.Blocks;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import nl.snowie.Category;
import nl.snowie.SnowModule;

public class AutoCrystal extends SnowModule {
    private int cooldown;

    public AutoCrystal() { super("AutoCrystal", "Places and breaks crystals near players", Category.COMBAT); }

    @Override
    public void onTick() {
        if (!ready() || mc.currentScreen != null) return;
        if (cooldown-- > 0) return;
        var p = mc.player;
        PlayerEntity target = nearestPlayer(8);
        if (target == null) return;

        // 1) break crystals that are close to the target
        for (EndCrystalEntity c : mc.world.getEntitiesByClass(EndCrystalEntity.class, p.getBoundingBox().expand(5), e -> true)) {
            if (c.distanceTo(target) <= 6) {
                mc.interactionManager.attackEntity(p, c);
                p.swingHand(Hand.MAIN_HAND);
                cooldown = 2;
                return;
            }
        }

        // 2) place a crystal
        int slot = findHotbar(s -> s.isOf(Items.END_CRYSTAL));
        if (slot == -1) return;
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        BlockPos center = target.getBlockPos();
        for (BlockPos pos : BlockPos.iterate(center.add(-3, -1, -3), center.add(3, 0, 3))) {
            var state = mc.world.getBlockState(pos);
            if (!state.isOf(Blocks.OBSIDIAN) && !state.isOf(Blocks.BEDROCK)) continue;
            if (!mc.world.getBlockState(pos.up()).isAir() || !mc.world.getBlockState(pos.up(2)).isAir()) continue;
            if (p.getEyePos().distanceTo(Vec3d.ofCenter(pos)) > 4.5) continue;
            if (!mc.world.getOtherEntities(null, new Box(pos.up()).stretch(0, 1, 0)).isEmpty()) continue;
            double d = pos.getSquaredDistance(target.getPos());
            if (d < bestDist) { bestDist = d; best = pos.toImmutable(); }
        }
        if (best == null) return;
        p.getInventory().setSelectedSlot(slot);
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND,
                new BlockHitResult(Vec3d.ofCenter(best).add(0, 0.5, 0), Direction.UP, best, false));
        p.swingHand(Hand.MAIN_HAND);
        cooldown = 2;
    }
}
