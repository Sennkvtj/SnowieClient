package nl.snowie.modules;

import net.minecraft.client.gui.DrawContext;
import nl.snowie.Category;
import nl.snowie.Hud;
import nl.snowie.SnowModule;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class TimeDateGui extends SnowModule {
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm:ss");
    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("dd-MM-yyyy");

    public TimeDateGui() { super("Time/Date", "Real time, date and in-game time", Category.HUD); }

    @Override
    public void onHud(DrawContext ctx) {
        if (mc.world == null) return;
        LocalDateTime now = LocalDateTime.now();
        long tod = mc.world.getTimeOfDay();
        long day = tod / 24000L;
        long t = tod % 24000L;
        int hh = (int) ((t / 1000 + 6) % 24);
        int mm = (int) ((t % 1000) * 60 / 1000);
        Hud.panel(ctx, "Time", List.of(
                now.format(TIME) + "   " + now.format(DATE),
                String.format("In-game: day %d  %02d:%02d", day, hh, mm)));
    }
}
