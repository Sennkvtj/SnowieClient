package nl.snowie;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.List;

public final class Hud {
    /** Vertical cursor for the stacked panels on the left side. */
    public static int leftY = 6;

    public static void panel(DrawContext ctx, String title, List<String> lines) {
        MinecraftClient mc = MinecraftClient.getInstance();
        int x = 6;
        int width = mc.textRenderer.getWidth(title);
        for (String l : lines) width = Math.max(width, mc.textRenderer.getWidth(l));
        width += 12;
        int height = 14 + lines.size() * 10 + 2;
        ctx.fill(x, leftY, x + width, leftY + height, Theme.HUD_BG);
        ctx.fill(x, leftY, x + 2, leftY + height, Theme.ICE);
        ctx.drawText(mc.textRenderer, title, x + 6, leftY + 3, Theme.ICE, true);
        int y = leftY + 14;
        for (String l : lines) {
            ctx.drawText(mc.textRenderer, l, x + 6, y, Theme.SNOW, false);
            y += 10;
        }
        leftY += height + 4;
    }

    private Hud() {}
}
