package nl.snowie;

/** Snow / cold / blue colour palette (ARGB). */
public final class Theme {
    public static final int WHITE = 0xFFFFFFFF;
    public static final int SNOW = 0xFFEAF6FF;
    public static final int ICE = 0xFF8FD3FF;
    public static final int BLUE = 0xFF3D8BFF;
    public static final int DEEP = 0xFF0B1626;
    public static final int PANEL = 0xE0101E33;
    public static final int PANEL_HEADER = 0xF01B4F8F;
    public static final int MUTED = 0xFF9DB4CC;
    public static final int HUD_BG = 0x990B1626;
    private Theme() {}
}
