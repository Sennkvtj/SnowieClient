package nl.snowie;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;

import java.util.function.Predicate;

public abstract class SnowModule {
    protected static final MinecraftClient mc = MinecraftClient.getInstance();

    public final String name;
    public final String description;
    public final Category category;
    private boolean enabled;

    protected SnowModule(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    public boolean isEnabled() { return enabled; }
    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean value) {
        if (value == enabled) return;
        enabled = value;
        try {
            if (value) onEnable(); else onDisable();
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}
    public void onHud(DrawContext ctx) {}

    protected boolean ready() {
        return mc.player != null && mc.world != null && mc.interactionManager != null;
    }

    protected int findHotbar(Predicate<ItemStack> filter) {
        for (int i = 0; i < 9; i++) {
            if (filter.test(mc.player.getInventory().getStack(i))) return i;
        }
        return -1;
    }

    protected PlayerEntity nearestPlayer(double range) {
        PlayerEntity best = null;
        double bestDist = range * range;
        for (PlayerEntity e : mc.world.getPlayers()) {
            if (e == mc.player || !e.isAlive() || e.isSpectator()) continue;
            double d = mc.player.squaredDistanceTo(e);
            if (d < bestDist) { bestDist = d; best = e; }
        }
        return best;
    }
}
