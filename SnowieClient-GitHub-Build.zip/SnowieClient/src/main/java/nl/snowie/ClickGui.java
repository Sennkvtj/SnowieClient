package nl.snowie;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public class ClickGui extends Screen {
    private static final int PW = 104, ROW = 14, HEAD = 18, GAP = 8;

    public ClickGui() {
        super(Text.literal("Snowie Client"));
    }

    @Override
    public boolean shouldPause() { return false; }

    private List<SnowModule> modulesOf(Category c) {
        List<SnowModule> list = new ArrayList<>();
        for (SnowModule m : SnowieClient.modules.modules) if (m.category == c) list.add(m);
        return list;
    }

    private int panelX(int index) {
        int total = Category.values().length * (PW + GAP) - GAP;
        return (width - total) / 2 + index * (PW + GAP);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.fillGradient(0, 0, width, height, 0x90061224, 0x902A6FB8);

        // falling snow
        long t = System.currentTimeMillis();
        for (int i = 0; i < 80; i++) {
            int x = (int) (((i * 97L) % width + Math.sin(i + t / 1200.0) * 10 + width) % width);
            int y = (int) (((t / (16 + (i % 5) * 7)) + i * 53L) % height);
            int s = (i % 3 == 0) ? 2 : 1;
            ctx.fill(x, y, x + s, y + s, 0xCCFFFFFF);
        }

        ctx.drawCenteredTextWithShadow(textRenderer, "Snowie Client", width / 2, 6, Theme.ICE);

        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            int x = panelX(i), y = 24;
            List<SnowModule> mods = modulesOf(cats[i]);
            int h = HEAD + mods.size() * ROW + 2;
            ctx.fill(x, y, x + PW, y + h, Theme.PANEL);
            ctx.fill(x, y, x + PW, y + HEAD, Theme.PANEL_HEADER);
            ctx.drawText(textRenderer, cats[i].label, x + 6, y + 5, Theme.WHITE, true);
            int ry = y + HEAD;
            for (SnowModule m : mods) {
                boolean hover = mouseX >= x && mouseX < x + PW && mouseY >= ry && mouseY < ry + ROW;
                if (m.isEnabled()) ctx.fill(x + 2, ry, x + PW - 2, ry + ROW, 0x803D8BFF);
                else if (hover) ctx.fill(x + 2, ry, x + PW - 2, ry + ROW, 0x40FFFFFF);
                ctx.drawText(textRenderer, m.name, x + 7, ry + 3, m.isEnabled() ? Theme.ICE : Theme.MUTED, false);
                ry += ROW;
            }
        }
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (click.button() == 0) {
            double mx = click.x(), my = click.y();
            Category[] cats = Category.values();
            for (int i = 0; i < cats.length; i++) {
                int x = panelX(i);
                int ry = 24 + HEAD;
                for (SnowModule m : modulesOf(cats[i])) {
                    if (mx >= x && mx < x + PW && my >= ry && my < ry + ROW) {
                        m.toggle();
                        return true;
                    }
                    ry += ROW;
                }
            }
        }
        return super.mouseClicked(click, doubled);
    }
}
