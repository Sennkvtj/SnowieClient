package nl.snowie;

public enum Category {
    COMBAT("Combat"), MOVEMENT("Movement"), RENDER("Render"), WORLD("World"), PLAYER("Player"), HUD("HUD");
    public final String label;
    Category(String label) { this.label = label; }
}
