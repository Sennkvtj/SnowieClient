package nl.snowie.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import nl.snowie.SnowieClient;
import nl.snowie.modules.AntiKnockback;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerMixin {
    @Inject(method = "onEntityVelocityUpdate", at = @At("HEAD"), cancellable = true)
    private void snowie$noKb(EntityVelocityUpdateS2CPacket packet, CallbackInfo ci) {
        var player = MinecraftClient.getInstance().player;
        if (player != null && SnowieClient.modules != null && SnowieClient.modules.on(AntiKnockback.class)
                && packet.getEntityId() == player.getId()) {
            ci.cancel();
        }
    }
}
