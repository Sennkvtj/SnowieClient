package nl.snowie.mixin;

import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;
import nl.snowie.modules.CustomSky;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientWorld.class)
public abstract class ClientWorldMixin {
    @Inject(method = "getSkyColor", at = @At("RETURN"), cancellable = true)
    private void snowie$sky(Vec3d cameraPos, float tickDelta, CallbackInfoReturnable<Integer> cir) {
        if (CustomSky.active) cir.setReturnValue(CustomSky.COLOR);
    }
}
