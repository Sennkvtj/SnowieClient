package nl.snowie.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.Entity;
import nl.snowie.SnowieClient;
import nl.snowie.modules.PlayerEsp;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "isGlowing", at = @At("HEAD"), cancellable = true)
    private void snowie$glow(CallbackInfoReturnable<Boolean> cir) {
        if (SnowieClient.modules != null && SnowieClient.modules.on(PlayerEsp.class)
                && (Object) this instanceof AbstractClientPlayerEntity p
                && p != MinecraftClient.getInstance().player) {
            cir.setReturnValue(true);
        }
    }
}
