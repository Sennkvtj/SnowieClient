package nl.snowie.mixin;

import net.minecraft.client.render.Camera;
import net.minecraft.util.math.Vec3d;
import nl.snowie.SnowieClient;
import nl.snowie.modules.Freecam;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow
    protected abstract void setPos(Vec3d pos);

    @Inject(method = "update", at = @At("TAIL"))
    private void snowie$freecam(CallbackInfo ci) {
        if (SnowieClient.modules != null && SnowieClient.modules.on(Freecam.class)) {
            setPos(Freecam.pos);
        }
    }
}
